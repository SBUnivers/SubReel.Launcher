using System.Windows;
using SubReel.Launcher.App.DesignSystem;
using SubReel.Launcher.App.ViewModels;

namespace SubReel.Launcher.App;

public partial class MainWindow : Window
{
    private readonly IWindowBackdropService _backdrop;

    public MainWindow(MainViewModel viewModel, IWindowBackdropService backdrop)
    {
        InitializeComponent();
        DataContext = viewModel;
        _backdrop = backdrop;
    }

    protected override void OnSourceInitialized(EventArgs e)
    {
        base.OnSourceInitialized(e);
        _backdrop.Apply(this);
    }

    private void Minimize_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
    private void Maximize_Click(object sender, RoutedEventArgs e) => WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
    private void Close_Click(object sender, RoutedEventArgs e) => Close();

    private void AccountMenu_Click(object sender, RoutedEventArgs e)
    {
        if (sender is FrameworkElement element && element.ContextMenu is { } menu)
        {
            menu.PlacementTarget = element;
            menu.IsOpen = true;
        }
    }
}
