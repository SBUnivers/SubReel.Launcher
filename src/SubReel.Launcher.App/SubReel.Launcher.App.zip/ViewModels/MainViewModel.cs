using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using SubReel.Launcher.App.Navigation;

namespace SubReel.Launcher.App.ViewModels;

public partial class MainViewModel : ObservableObject
{
    private readonly INavigationService _navigation;

    public ObservableCollection<NavigationItem> NavigationItems =>
        _navigation.Items;

    public SectionViewModel? CurrentViewModel =>
        _navigation.CurrentViewModel;

    public string PageTitle =>
        _navigation.CurrentItem?.Title ?? "SubReel Launcher";

    public string StatusText => $"Раздел: {PageTitle}";

    public MainViewModel(INavigationService navigation)
    {
        _navigation = navigation;
        _navigation.PropertyChanged += OnNavigationPropertyChanged;
    }

    private void OnNavigationPropertyChanged(
        object? sender,
        System.ComponentModel.PropertyChangedEventArgs e)
    {
        if (e.PropertyName == nameof(INavigationService.CurrentItem))
        {
            OnPropertyChanged(nameof(PageTitle));
            OnPropertyChanged(nameof(StatusText));
        }

        if (e.PropertyName == nameof(INavigationService.CurrentViewModel))
        {
            OnPropertyChanged(nameof(CurrentViewModel));
        }
    }

    [RelayCommand]
    private void Navigate(string key)
    {
        _navigation.NavigateTo(key);
    }
}