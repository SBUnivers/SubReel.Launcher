﻿using System.Windows;
using SubReel.Launcher.App.ViewModels;

namespace SubReel.Launcher.App;

public partial class MainWindow : Window
{
    public MainWindow(MainViewModel viewModel)
    {
        InitializeComponent();
        DataContext = viewModel;
    }
}