﻿
using System.IO;
using System.Windows;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;
using SubReel.Launcher.App.Modules;
using SubReel.Launcher.App.Navigation;
using SubReel.Launcher.App.ViewModels;

namespace SubReel.Launcher.App;

public partial class App : Application
{
    private IHost? _host;

    protected override async void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        try
        {
            var logDirectory = Path.Combine(
                Environment.GetFolderPath(
                    Environment.SpecialFolder.LocalApplicationData),
                "SubReel",
                "Launcher",
                "Logs");

            Directory.CreateDirectory(logDirectory);

            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Information()
                .WriteTo.File(
                    Path.Combine(logDirectory, "launcher-.log"),
                    rollingInterval: RollingInterval.Day,
                    retainedFileCountLimit: 14)
                .CreateLogger();

            var modules = new ILauncherModule[]
            {
                new HomeModule(),
                new InstancesModule(),
                new ModsModule(),
                new SettingsModule()
            };

            var builder = Host.CreateApplicationBuilder();

            builder.Logging.ClearProviders();
            builder.Services.AddSerilog();

            foreach (var module in modules)
            {
                module.ConfigureServices(builder.Services);
                builder.Services.AddSingleton<ILauncherModule>(module);
            }

            builder.Services.AddSingleton<INavigationService, NavigationService>();
            builder.Services.AddSingleton<MainViewModel>();
            builder.Services.AddSingleton<MainWindow>();

            _host = builder.Build();

            await _host.StartAsync();

            var navigation = _host.Services
                .GetRequiredService<INavigationService>();

            foreach (var module in _host.Services
                         .GetServices<ILauncherModule>())
            {
                module.ConfigureNavigation(navigation);
            }

            navigation.NavigateTo("home");

            var window = _host.Services.GetRequiredService<MainWindow>();
            MainWindow = window;
            window.Show();

            Log.Information("SubReel Launcher запущен");
        }
        catch (Exception ex)
        {
            Log.Fatal(ex, "Не удалось запустить SubReel Launcher");

            MessageBox.Show(
                $"Не удалось запустить лаунчер.\n\n{ex.Message}",
                "SubReel Launcher",
                MessageBoxButton.OK,
                MessageBoxImage.Error);

            Shutdown(-1);
        }
    }

    protected override async void OnExit(ExitEventArgs e)
    {
        if (_host is not null)
        {
            try
            {
                await _host.StopAsync();
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Ошибка при остановке лаунчера");
            }
            finally
            {
                _host.Dispose();
            }
        }

        await Log.CloseAndFlushAsync();

        base.OnExit(e);
    }
}
