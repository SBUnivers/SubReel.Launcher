﻿using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using SubReel.Launcher.App.ViewModels;

namespace SubReel.Launcher.App.Navigation;

public sealed class NavigationService : ObservableObject, INavigationService
{
    public ObservableCollection<NavigationItem> Items { get; } = [];

    private NavigationItem? _currentItem;

    public NavigationItem? CurrentItem
    {
        get => _currentItem;
        private set => SetProperty(ref _currentItem, value);
    }

    private SectionViewModel? _currentViewModel;

    public SectionViewModel? CurrentViewModel
    {
        get => _currentViewModel;
        private set => SetProperty(ref _currentViewModel, value);
    }

    public void Register(NavigationItem item)
    {
        ArgumentNullException.ThrowIfNull(item);

        if (Items.Any(x => x.Key == item.Key))
        {
            throw new InvalidOperationException(
                $"Пункт навигации '{item.Key}' уже зарегистрирован.");
        }

        Items.Add(item);
    }

    public bool NavigateTo(string key)
    {
        var item = Items.FirstOrDefault(x => x.Key == key);

        if (item is null)
            return false;

        CurrentItem = item;
        CurrentViewModel = new SectionViewModel(
            item.Title,
            item.Icon,
            item.Description);

        return true;
    }
}