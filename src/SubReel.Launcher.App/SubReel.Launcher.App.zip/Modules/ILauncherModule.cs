using Microsoft.Extensions.DependencyInjection;
using SubReel.Launcher.App.Navigation;

namespace SubReel.Launcher.App.Modules;

public interface ILauncherModule
{
    string Id { get; }

    void ConfigureServices(IServiceCollection services);

    void ConfigureNavigation(INavigationService navigation);
}