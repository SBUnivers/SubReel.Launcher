﻿using Microsoft.Extensions.DependencyInjection;
using SubReel.Launcher.App.Navigation;

namespace SubReel.Launcher.App.Modules;

public sealed class HomeModule : ILauncherModule
{
    public string Id => "home";

    public void ConfigureServices(IServiceCollection services)
    {
        // Сервисы главной страницы добавим по мере развития.
    }

    public void ConfigureNavigation(INavigationService navigation)
    {
        navigation.Register(new NavigationItem(
            "home",
            "Главная",
            "⌂",
            "Добро пожаловать в SubReel Launcher."));
    }
}

public sealed class InstancesModule : ILauncherModule
{
    public string Id => "instances";

    public void ConfigureServices(IServiceCollection services)
    {
        // Здесь появятся сервисы игровых инстансов.
    }

    public void ConfigureNavigation(INavigationService navigation)
    {
        navigation.Register(new NavigationItem(
            "instances",
            "Сборки",
            "▣",
            "Управление игровыми версиями и сборками Minecraft."));
    }
}

public sealed class ModsModule : ILauncherModule
{
    public string Id => "mods";

    public void ConfigureServices(IServiceCollection services)
    {
        // Здесь появятся сервисы управления модами.
    }

    public void ConfigureNavigation(INavigationService navigation)
    {
        navigation.Register(new NavigationItem(
            "mods",
            "Моды",
            "✧",
            "Установка, обновление и управление модификациями."));
    }
}

public sealed class SettingsModule : ILauncherModule
{
    public string Id => "settings";

    public void ConfigureServices(IServiceCollection services)
    {
        // Здесь появятся сервисы настроек.
    }

    public void ConfigureNavigation(INavigationService navigation)
    {
        navigation.Register(new NavigationItem(
            "settings",
            "Настройки",
            "⚙",
            "Настройки Java, памяти, загрузок и интерфейса."));
    }
}